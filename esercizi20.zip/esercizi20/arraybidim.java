public class arraybidim {
    public static void main(String[] args){
        int [][] myNumbers = {{1,2,3,4},{5,6,7}};
        System.out.println(myNumbers[0][2]);

        for(int i=0; i<myNumbers.lenght; i++){
            for(int j=0; j<myNumbers[i].lenght; j++){
                System.out.println(myNumbers[i][j]);
            }
        }
    
        //fai con for each

        for (int[] riga : myNumbers){
            for(int elemento : riga){
                System.out.println
            }
        }
    }
}
